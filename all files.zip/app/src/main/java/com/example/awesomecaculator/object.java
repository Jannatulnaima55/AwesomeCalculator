package com.example.awesomecaculator;

public class object {
}
