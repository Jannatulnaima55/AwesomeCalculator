package com.example.awesomecaculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import static java.lang.Math.log;

public class MainActivity extends AppCompatActivity {

    Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b0,bdot,bequal,bplus,bmin,bmul,bdiv,bsinh,bcosh,btanh,broot,bpower,bln,blog,btan,bcos,bsin,bb1,bb2,bac,bdel;
    TextView display;

    double a, numone, numtwo;

    boolean msinh,mcosh,mtanh,msin,mcos,mtan,mpower,marithematic,mplus,mmin,mmul,mdiv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);
        b4 = findViewById(R.id.b4);
        b5 = findViewById(R.id.b5);
        b6 = findViewById(R.id.b6);
        b7= findViewById(R.id.b7);
        b8= findViewById(R.id.b8);
        b9 = findViewById(R.id.b9);
        b0 = findViewById(R.id.b0);
        bdot = findViewById(R.id.bdot);
        bequal = findViewById(R.id.bequal);
        bplus = findViewById(R.id.bplus);
        bmin = findViewById(R.id.bmin);
        bmul = findViewById(R.id.bmul);
        bdiv = findViewById(R.id.bdiv);
        bln = findViewById(R.id.bln);
        blog = findViewById(R.id.blog);
        btan = findViewById(R.id.btan);
        bsin = findViewById(R.id.bsin);
        bcos = findViewById(R.id.bcos);
        bb1 = findViewById(R.id.bb1);
        bb2 = findViewById(R.id.bb2);
        bac = findViewById(R.id.bac);
        bdel = findViewById(R.id.bdel);
        bsinh = findViewById(R.id.bsinh);
        bcosh = findViewById(R.id.bcosh);
        btanh = findViewById(R.id.btanh);
        broot = findViewById(R.id.broot);
        bpower = findViewById(R.id.bpower);


        display = findViewById(R.id.display);


        //onclick listeners

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display.setText(display.getText() + "1");
                marithematic = true;
            }
        });


        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display.setText(display.getText() + "2");
                marithematic = true;
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display.setText(display.getText() + "3");
                marithematic = true;
            }
        });


        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display.setText(display.getText() + "4");
                marithematic = true;
            }
        });


        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display.setText(display.getText() + "5");
                marithematic = true;
            }
        });

        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display.setText(display.getText() + "6");
                marithematic = true;
            }
        });

        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display.setText(display.getText() + "7");
                marithematic = true;
            }
        });


        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display.setText(display.getText() + "8");
                marithematic = true;
            }
        });


        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display.setText(display.getText() + "9");
                marithematic = true;
            }
        });

        b0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display.setText(display.getText() + "0");
                marithematic = true;
            }
        });

        bdot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display.setText(display.getText() + ".");


            }
        });

        bac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display.setText(" ");
            }
        });

        bplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    numone = Double.parseDouble(display.getText() + " ");
                    mplus = true;
                    display.setText(null);
                }

                catch (Exception e)
                {
                    display.setText("Scientific error");

                }
            }
        });

        bmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    numone = Double.parseDouble(display.getText() + " ");
                    mmin= true;
                    display.setText(null);
                }

                catch (Exception e)
                {
                    display.setText("Scientific error");
                }

            }
        });

        bmul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    numone = Double.parseDouble(display.getText() + " ");
                    mmul = true;
                    display.setText(" ");
                }

                catch (Exception e)
                {
                    display.setText("Scientific error");
                }

            }
        });

        bdiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    numone = Double.parseDouble(display.getText() + " ");
                    mdiv = true;
                    display.setText(null);
                }

                catch (Exception e)
                {
                    display.setText("Scientific error");
                }
            }
        });


        bb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display.setText(display.getText() + "(");
            }
        });

        bb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display.setText(display.getText() + ")");
            }
        });


        bsin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    a = Math.sin(Double.parseDouble(display.getText().toString()));
                    display.setText(" ");
                    display.setText(display.getText().toString() + a);
                }

                catch (Exception e)
                {
                    display.setText("Scientific error");
                }

                display.setText("Sin");
                msin = true;
            }
        });

        bcos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    a = Math.cos(Double.parseDouble(display.getText().toString()));
                    display.setText(" ");
                    display.setText(display.getText().toString() + a);
                }

                catch (Exception e)
                {
                    display.setText("Scientific error");
                }

                display.setText("Cos");
                mcos = true;
            }
        });

        btan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    a = Math.tan(Double.parseDouble(display.getText().toString()));
                    display.setText(" ");
                    display.setText(display.getText().toString() + a);
                }

                catch (Exception e)
                {
                    display.setText("Scientific error");
                }

                display.setText(" Tan ");
                mtan = true;
            }
        });

        bln.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    a = (Double.parseDouble(display.getText().toString()));
                    double result = (-Math.log(1-a)) / a;
                    display.setText(" ");
                    display.setText(display.getText().toString() + result);
                }

                catch (Exception e)
                {
                    display.setText("Scientific error");
                }
            }
        });

        blog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    a = Math.log(Double.parseDouble(display.getText().toString()));
                    display.setText(" ");
                    display.setText(display.getText().toString() + a);
                }

                catch (Exception e)
                {
                    display.setText("Scientific error");
                }

            }
        });

        bsinh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    a = Math.sinh(Double.parseDouble(display.getText().toString()));
                    display.setText(" ");
                    display.setText(display.getText().toString() + a);
                }

                catch (Exception e)
                {
                    display.setText("Scientific error");
                }

                display.setText(" sin-1");
                msinh = true;
            }
        });


        bcosh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    a = Math.cosh(Double.parseDouble(display.getText().toString()));
                    display.setText(" ");
                    display.setText(display.getText().toString() + a);
                }

                catch (Exception e)
                {
                    display.setText("Scientific error");
                }

                display.setText(" cos-1 ");
                mcosh = true;
            }
        });


        btanh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    a = Math.tanh(Double.parseDouble(display.getText().toString()));
                    display.setText(" ");
                    display.setText(display.getText().toString() + a);
                }

                catch (Exception e)
                {
                    display.setText("Scientific error");
                }

                display.setText("tan−1");
                mtanh = true;
            }
        });


        broot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    a = Math.sqrt(Double.parseDouble(display.getText().toString()));
                    display.setText(" ");
                    display.setText(display.getText().toString() + a);
                }

                catch (Exception e)
                {
                    display.setText("Scientific error");
                }
            }
        });

        bpower.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    numone = Double.parseDouble(display.getText() + "");
                    mpower = true;
                    display.setText(null);
                }

                catch (Exception e)
                {
                    display.setText("Scientific error");
                }
            }
        });

        bdel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                   String str;
                   str = display.getText().toString();
                   str = str.substring(0, str.length()-1);
                   display.setText(str);
                }

                catch (Exception e)
                {
                    display.setText("Scientific error");
                }
            }
        });

        bequal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (msin == true) {
                if (marithematic == true) {
                    String str;
                    str = display.getText().toString();
                    str = str.substring(3);
                    a = Math.sin(Double.parseDouble(str));
                    display.setText(a + "");
                    marithematic = false;
                    msin = false;
                }

                }
            }
        });

              if (mcos == true) {
                if (marithematic == true) {
                    String str;
                    str = display.getText().toString();
                    str = str.substring(3);
                    a = Math.cos(Double.parseDouble(str));
                    display.setText(a + "");
                    marithematic = false;
                    mcos = false;
                }

            }


        if (mtan == true) {
            if (marithematic == true) {
                String str;
                str = display.getText().toString();
                str = str.substring(3);
                a = Math.tan(Double.parseDouble(str));
                display.setText(a + "");
                marithematic = false;
                mtan = false;
            }

        }


        if (msinh == true) {
            if (marithematic == true) {
                String str;
                str = display.getText().toString();
                str = str.substring(5);
                a = Math.sinh(Double.parseDouble(str));
                display.setText(a + "");
                marithematic = false;
                msinh = false;
            }

        }


        if (mcosh == true) {
            if (marithematic == true) {
                String str;
                str = display.getText().toString();
                str = str.substring(5);
                a = Math.cosh(Double.parseDouble(str));
                display.setText(a + "");
                marithematic = false;
                mcosh = false;
            }

        }

        if (mtanh == true) {
            if (marithematic == true) {
                String str;
                str = display.getText().toString();
                str = str.substring(5);
                a = Math.tanh(Double.parseDouble(str));
                display.setText(a + "");
                marithematic = false;
                mtanh = false;
            }

        }


        if (mpower == true) {
            numtwo = Double.parseDouble(display.getText() + " ");
            int exp = (int) Math.pow(numone, numtwo);
            display.setText(exp+" ");
            mpower = false;
        }

        if (mplus == true) {
            numtwo = Double.parseDouble(display.getText() + " ");
            display.setText(numone + numtwo + " ");
            mplus = false;
        }

        if (mmin == true) {
            numtwo = Double.parseDouble(display.getText() + " ");
            display.setText(numone - numtwo + " ");
            mmin = false;
        }

        if (mmul == true) {
            numtwo = Double.parseDouble(display.getText() + " ");
            display.setText(numone * numtwo + " ");
            mmul = false;
        }

        if (mdiv == true) {
            numtwo = Double.parseDouble(display.getText() + " ");
            display.setText(numone / numtwo + " ");
            mdiv = false;
        }
    }
}
